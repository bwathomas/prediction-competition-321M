"""Runtime model.py for the metadata-only latent-factor submission.

UPDATED CALIBRATION + LABELING VARIANT
=======================================

This file replaces the original LFM ``model.py`` that discarded the
``labeled`` argument unused and applied no calibration.  We now:

  1. Vendor the transformer pipeline's ``_Calibrator``:
     type-conditional partial-pool intercept (b_global, delta_type, per_bc).
     Fit happens whenever ``labeled`` changes (fingerprint cache) and is
     applied to every uncalibrated probability before clipping.

  2. Expose module-level symbols (``_BC_TO_ID``, ``_SUBJECT_TO_ID``,
     ``normalize_condition``, ``stable_sha256``,
     ``extract_name_from_subject_content``, ``_predict_uncalibrated``)
     so ``labeling.py`` can implement dual-pool stratified acquisition.

  3. Treat ``item_content`` as cosmetic -- the LFM is item-content-
     independent, so ``_predict_uncalibrated`` only consumes
     (benchmark, condition, subject_content).
"""

from __future__ import annotations

import hashlib
import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import torch

from latent_factor_pytorch import (
    LatentFactorInference,
    extract_name_from_subject_content,
    load_artifacts,
)

# Same scalar constants as the original LFM runtime.
EPS = 1e-3
EPS_LOGIT = 1e-7
DEFAULT_PROB = 0.5

# Ridge regularization strengths for the 4-stage calibrator fit
# (matching src/export_submission.py: lambda_global=20, lambda_bc=20,
# lambda_type=10 -- these are sane defaults for K=75 labels per round).
_RIDGE_LAMBDA_GLOBAL = 20.0
_RIDGE_LAMBDA_BC = 20.0
_RIDGE_LAMBDA_TYPE = 10.0


# ---------------------------------------------------------------------------
# Tiny helpers (shared with labeling.py)
# ---------------------------------------------------------------------------


def normalize_condition(value) -> str:
    """Literal "none" sentinel; matches harness/utils.normalize_condition."""
    if value is None:
        return "none"
    s = str(value)
    if s == "" or s.lower() in {"nan", "none", "null"}:
        return "none"
    return s


def stable_sha256(*parts: str) -> str:
    """Stable hex digest joining parts with a NUL byte."""
    h = hashlib.sha256()
    for part in parts:
        h.update(str(part).encode("utf-8", errors="replace"))
        h.update(b"\x00")
    return h.hexdigest()


def _sigmoid(x: float) -> float:
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)


def _logit(p: float) -> float:
    p = min(max(p, EPS_LOGIT), 1.0 - EPS_LOGIT)
    return math.log(p / (1.0 - p))


# ---------------------------------------------------------------------------
# Artifact load
# ---------------------------------------------------------------------------

_DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
_MODEL, _PREPROCESSOR, _CONFIG = load_artifacts(HERE, device=_DEVICE)
_INFERENCE = LatentFactorInference(_MODEL, _PREPROCESSOR, device=_DEVICE)


# ---------------------------------------------------------------------------
# Vocab views (consumed by labeling.py for novelty detection)
# ---------------------------------------------------------------------------


def _build_indexer_views():
    """Expose the preprocessor's vocabs as dict-like lookup tables.

    * _BC_TO_ID  : "<benchmark>::<condition_norm>" -> int
      Pulled from preprocessor.benchmark_condition_vocab.token_to_id.
      The 0 and 1 ids are MISSING/UNK respectively, so "in _BC_TO_ID" is
      only True for explicit training tokens (UNK is reserved for unseen).
      We strip the sentinels so the containment test is clean.

    * _SUBJECT_TO_ID : model_name -> int
      Pulled from preprocessor.model_id_vocab.token_to_id.  LFM keys
      subjects by display name (extracted from subject_content); we do
      NOT use sha256 here because the bundle does not ship the original
      subject_contents.
    """
    sentinels = {"__MISSING__", "__UNK__"}
    try:
        bc_v = dict(_PREPROCESSOR.benchmark_condition_vocab.token_to_id)
    except Exception:
        bc_v = {}
    try:
        m_v = dict(_PREPROCESSOR.model_id_vocab.token_to_id)
    except Exception:
        m_v = {}
    bc_v = {k: int(v) for k, v in bc_v.items() if k not in sentinels}
    m_v = {k: int(v) for k, v in m_v.items() if k not in sentinels}
    return bc_v, m_v


_BC_TO_ID, _SUBJECT_TO_ID = _build_indexer_views()


# ---------------------------------------------------------------------------
# Uncalibrated prediction (the calibrator fits on these)
# ---------------------------------------------------------------------------


def _predict_uncalibrated(
    benchmark: str,
    condition: str,
    subject_content: str,
    item_content: str = "",
) -> float:
    """Forward-only LFM probability for one (m, b, c) row.

    ``item_content`` is accepted only to match the four-string runtime
    contract; the LFM is item-content-independent.
    """
    try:
        p = _INFERENCE.predict_one(
            str(benchmark or ""),
            str(condition or "none"),
            str(subject_content or ""),
        )
    except Exception:
        return DEFAULT_PROB
    if not math.isfinite(p):
        return DEFAULT_PROB
    return float(min(max(p, EPS_LOGIT), 1.0 - EPS_LOGIT))


# ---------------------------------------------------------------------------
# Ridge-regularized intercept solver  (vendored)
# ---------------------------------------------------------------------------


def _fit_intercept_ridge(ps, ys, *, target_b: float = 0.0, ridge: float = _RIDGE_LAMBDA_GLOBAL) -> float:
    """Newton solve for b minimizing sum BCE(logit(p)+b, y) + ridge*(b-target_b)^2.

    Clamped to [-5, 5] so a pathological tiny-N round can't blow up apply().
    """
    if not ps:
        return float(target_b)
    zs = [_logit(p) for p in ps]
    b = float(target_b)
    for _ in range(80):
        g = 2.0 * ridge * (b - target_b)
        h = 2.0 * ridge
        for z, y in zip(zs, ys):
            q = _sigmoid(z + b)
            g += q - y
            h += q * (1.0 - q)
        if h < 1e-9:
            break
        step = g / h
        new_b = b - step
        if not math.isfinite(new_b):
            break
        if abs(new_b - b) < 1e-8:
            b = new_b
            break
        b = new_b
    if not math.isfinite(b):
        return float(target_b)
    return max(-5.0, min(5.0, float(b)))


# ---------------------------------------------------------------------------
# Type-conditional partial-pool intercept calibrator  (vendored)
# ---------------------------------------------------------------------------


class _Calibrator:
    """3-tier calibrator: per_bc -> global+delta_type -> identity.

    State:
      * ``b_global``     -- global intercept shift (every row).
      * ``delta_type``   -- additional shift for NEW-bc rows only
                            (bc_key not in _BC_TO_ID at fit time).
      * ``per_bc``       -- per-(benchmark,condition) full intercept
                            (already includes b_global + delta_type*is_new).
    """

    def __init__(self, state=None) -> None:
        if isinstance(state, dict) and state.get("kind") == "intercept":
            self.b_global = float(state.get("b", 0.0))
        else:
            self.b_global = 0.0
        self.delta_type = 0.0
        self.per_bc = {}

    def fit_from_labeled(self, labeled_list) -> None:
        if not labeled_list:
            return
        ps = []
        ys = []
        bcs = []
        is_new_list = []
        for ex in labeled_list:
            try:
                lbl = ex.get("label")
                if lbl is None:
                    continue
                y = float(lbl)
            except (TypeError, ValueError):
                continue
            if not math.isfinite(y):
                continue
            benchmark = str(ex.get("benchmark", "") or "")
            condition = normalize_condition(ex.get("condition", "none"))
            subject_content = str(ex.get("subject_content", "") or "")
            item_content = str(ex.get("item_content", "") or "")
            try:
                p_base = _predict_uncalibrated(benchmark, condition, subject_content, item_content)
            except Exception:
                continue
            if not math.isfinite(p_base):
                continue
            bc_key = "{0}::{1}".format(benchmark, condition)
            ps.append(float(p_base))
            ys.append(min(max(y, 0.0), 1.0))
            bcs.append(bc_key)
            is_new_list.append(0.0 if bc_key in _BC_TO_ID else 1.0)
        if not ps:
            return
        # Stage 1: initial b_global on raw ps.
        self.b_global = _fit_intercept_ridge(ps, ys, target_b=0.0, ridge=_RIDGE_LAMBDA_GLOBAL)
        # Stage 2: delta_type from new-bc rows, with b_global as fixed offset.
        new_ps, new_ys = [], []
        for i, flag in enumerate(is_new_list):
            if flag > 0.5:
                new_ps.append(_sigmoid(_logit(ps[i]) + self.b_global))
                new_ys.append(ys[i])
        if new_ps:
            self.delta_type = _fit_intercept_ridge(new_ps, new_ys, target_b=0.0, ridge=_RIDGE_LAMBDA_TYPE)
        else:
            self.delta_type = 0.0
        # Stage 3: re-fit b_global with delta_type*is_new pre-applied.
        shifted_ps = [
            _sigmoid(_logit(ps[i]) + self.delta_type * is_new_list[i])
            for i in range(len(ps))
        ]
        self.b_global = _fit_intercept_ridge(shifted_ps, ys, target_b=0.0, ridge=_RIDGE_LAMBDA_GLOBAL)
        # Stage 4: per-bc deltas, with target = b_global + delta_type*is_new_for_bc.
        bc_to_pairs = {}
        for p, y, bc, flag in zip(ps, ys, bcs, is_new_list):
            bucket = bc_to_pairs.setdefault(bc, ([], [], flag))
            bucket[0].append(p)
            bucket[1].append(y)
        self.per_bc = {}
        for bc_key, (lp, ly, flag) in bc_to_pairs.items():
            target = self.b_global + self.delta_type * flag
            b_bc = _fit_intercept_ridge(lp, ly, target_b=target, ridge=_RIDGE_LAMBDA_BC)
            self.per_bc[bc_key] = float(b_bc)

    def apply(self, p: float, bc_key: str = "") -> float:
        if not math.isfinite(p):
            return DEFAULT_PROB
        if isinstance(bc_key, str) and bc_key in self.per_bc:
            b = float(self.per_bc[bc_key])
        else:
            is_new = 0.0 if (isinstance(bc_key, str) and bc_key in _BC_TO_ID) else 1.0
            b = float(self.b_global) + float(self.delta_type) * is_new
        try:
            z = _logit(p) + b
            q = _sigmoid(z)
        except Exception:
            return DEFAULT_PROB
        if not math.isfinite(q):
            return DEFAULT_PROB
        return float(min(max(q, EPS_LOGIT), 1.0 - EPS_LOGIT))


# ---------------------------------------------------------------------------
# Per-round state (calibrator + label fingerprint cache + prob cache)
# ---------------------------------------------------------------------------


_CALIBRATOR = _Calibrator(None)
_LAST_LABELED_FINGERPRINT: tuple = ()
_PROB_CACHE: dict = {}


def _labeled_fingerprint(labeled) -> tuple:
    """Hash the labeled set so we only refit when its contents change.

    Keys on (benchmark, condition, model_name, sha256(item_content), label)
    so a different item with the same (subject, bc) does not collapse with
    its sibling.
    """
    if not labeled:
        return ()
    out = []
    for ex in labeled:
        bench = str(ex.get("benchmark", ""))
        cond = str(ex.get("condition", ""))
        subj = str(ex.get("subject_content", ""))
        item = str(ex.get("item_content", ""))
        try:
            lbl = float(ex.get("label", float("nan")))
        except (TypeError, ValueError):
            lbl = float("nan")
        out.append(
            (
                bench,
                cond,
                extract_name_from_subject_content(subj),
                stable_sha256(item),
                lbl,
            )
        )
    return tuple(sorted(out))


# ---------------------------------------------------------------------------
# predict()
# ---------------------------------------------------------------------------


def predict(input, labeled=None):
    """Return the probability that the subject answers correctly.

    The harness loads this module once per round and then calls predict()
    per candidate, passing the same ``labeled`` list to every call within
    a round.  We refit the calibrator only when that list changes (cheap
    fingerprint check).
    """
    global _LAST_LABELED_FINGERPRINT, _CALIBRATOR
    try:
        benchmark = str(input.get("benchmark", "") or "")
        condition = normalize_condition(input.get("condition", "none"))
        subject_content = str(input.get("subject_content", "") or "")
        item_content = str(input.get("item_content", "") or "")

        if labeled:
            fp = _labeled_fingerprint(labeled)
            if fp != _LAST_LABELED_FINGERPRINT:
                _LAST_LABELED_FINGERPRINT = fp
                _PROB_CACHE.clear()
                _CALIBRATOR = _Calibrator(None)
                _CALIBRATOR.fit_from_labeled(labeled)

        # The LFM is item-content-independent, so we cache by (bc, subject_name).
        name = extract_name_from_subject_content(subject_content)
        cache_key = (benchmark, condition, name)
        cached = _PROB_CACHE.get(cache_key)
        if cached is not None:
            return float(cached)

        p = _predict_uncalibrated(benchmark, condition, subject_content, item_content)
        bc_key = "{0}::{1}".format(benchmark, condition)
        p = _CALIBRATOR.apply(p, bc_key)
        p = float(min(max(p, EPS), 1.0 - EPS))
        _PROB_CACHE[cache_key] = p
        return p
    except Exception:
        return float(DEFAULT_PROB)
