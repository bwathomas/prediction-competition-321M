"""Adaptive-labeling acquisition function (dual-pool stratification).

Adapted from scripts/_calib_variants/base/labeling.py for the latent-factor
(LFM) submission.  The structural decisions are identical:

  * Split candidates into POOL A (new-bc-eligible) and POOL B
    (known-bc-eligible) by hashing item_content with FRACTION_NEW_POOL=0.95.
  * +1000 if (in_new_pool == is_new_bc), else +0.  Top-K-per-category then
    selects almost-all-new-bc rows when novelty is available.
  * Anchoring bonus rewards labels on subjects we have seen at training.

LFM-specific tweaks
-------------------
  * Novelty: ``bc_key not in _BC_TO_ID`` (the LFM preprocessor's
    benchmark_condition_vocab).
  * "Known subject": ``extract_name_from_subject_content(subject_content)
    in _SUBJECT_TO_ID`` (i.e. the model_name appeared in training).
    The LFM does NOT key subjects by sha256(subject_content), so we use
    model_name containment as the analogue of the upstream's sha256
    lookup.
  * No streamed-flush queue: the upstream's batch-enqueue side-effect
    is absent here (the LFM has no encoder to warm up).

Binary fallback
---------------
The LFM bundle does not ship ``_N_TRAIN_PER_BC`` / ``_N_TRAIN_PER_SUBJECT``,
so we always use the BINARY anchoring branch (anchoring = 1 if known subject
else 0).  This matches the upstream's documented "BINARY fallback".
"""

from __future__ import annotations

import hashlib
import math


# Fraction of items routed to the "new-prioritized" pool.  See
# scripts/_calib_variants/base/labeling.py for the 50-trial simulation
# that picked 0.95 (~82-85% NEW labels per round).
_FRACTION_NEW_POOL = 0.95


def _item_in_new_pool(item_content: str) -> bool:
    """Deterministic per-item assignment to POOL A (new) vs POOL B (known)."""
    h = hashlib.blake2b(item_content.encode("utf-8"), digest_size=8).digest()
    n = int.from_bytes(h, "little")
    return (n / float(2 ** 64)) < _FRACTION_NEW_POOL


def _stable_tiebreak(*parts: str) -> float:
    """Return a deterministic float in [-0.5, +0.5] derived from inputs."""
    h = hashlib.blake2b(("\x00".join(parts)).encode("utf-8"), digest_size=8).digest()
    n = int.from_bytes(h, "little")
    return (n / 2 ** 64) - 0.5


def acquisition_function(input: dict) -> float:  # noqa: A002 - mirror harness API
    benchmark = str(input.get("benchmark", "") or "")
    condition_raw = str(input.get("condition", "none") or "none")
    subject_content = str(input.get("subject_content", "") or "")
    item_content = str(input.get("item_content", "") or "")

    try:
        from model import (  # type: ignore
            _BC_TO_ID,
            _SUBJECT_TO_ID,
            normalize_condition,
            extract_name_from_subject_content,
        )
    except Exception:  # noqa: BLE001 - any failure -> uniform random fallback
        return 0.0

    try:
        condition = normalize_condition(condition_raw)
        bc_key = "{0}::{1}".format(benchmark, condition)
        is_new_bc = (bc_key not in _BC_TO_ID)

        # LFM subject identity = extracted model_name.  Known => present in
        # the trained model_id_vocab (a strict-train fit, so containment is
        # the analogue of "we have prior signal on this subject").
        subject_name = extract_name_from_subject_content(subject_content)
        is_known_subject = bool(subject_name) and (subject_name in _SUBJECT_TO_ID)
        anchoring = 1.0 if is_known_subject else 0.0

        in_new_pool = _item_in_new_pool(item_content)
        eligible = (in_new_pool == is_new_bc)
        bc_bonus = 1000.0 if eligible else 0.0

        tb = _stable_tiebreak(benchmark, condition, subject_content, item_content)
        score = bc_bonus + 10.0 * anchoring + tb
        if not math.isfinite(score):
            return 0.0
        return float(score)
    except Exception:  # noqa: BLE001 - platform handles 0.0 as random
        return 0.0
